package com.example.usageapplication;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.example.usageapplication.activity.GyroscopeActivity;
import com.example.usageapplication.datalogger.DataLoggerManager;
import com.kircherelectronics.fsensor.filter.averaging.MeanFilter;
import com.kircherelectronics.fsensor.util.rotation.RotationUtil;
import com.kircherelectronics.fsensor.filter.averaging.MeanFilter;
import com.kircherelectronics.fsensor.filter.gyroscope.OrientationGyroscope;
import com.kircherelectronics.fsensor.filter.gyroscope.fusion.complimentary.OrientationFusedComplimentary;
import com.kircherelectronics.fsensor.filter.gyroscope.fusion.kalman.OrientationFusedKalman;
import com.kircherelectronics.fsensor.util.rotation.RotationUtil;

import org.apache.commons.math3.complex.Quaternion;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity implements SensorEventListener, View.OnClickListener {

    //    private TextView steps;
//    private SensorManager sensorManager;
//    private Sensor angle;
    public int count=0;
    public float inclination =0;
    private double mAzimuth = 0;
    private float[] prev = {0f,0f,0f};
    private Menu menu;
    private TextView stepView;
    private int stepCount = 0;
    private static final int ABOVE = 1;
    private static final int BELOW = 0;
    private static int CURRENT_STATE = 0;
    private static int PREVIOUS_STATE = BELOW;
    //    private Button reset;
    private int sampleCount = 0;
    private long startTime;
    private long startTimer;
    private long endTimer;
    boolean SAMPLING_ACTIVE = true;
    private long streakStartTime;
    private long streakPrevTime;
    private OrientationGyroscope orientationGyroscope;

    private boolean hasAcceleration = false;
    private boolean hasMagnetic = false;
    //maps
    private Context mContext;
    private Resources mResources;
    private RelativeLayout mRelativeLayout;
    private Button start;
    private Button end;
    private Button startLocating;
    private Button stopLocating;
    private Button reset;
    private Button calib;
    private ImageView mImageView;
    Bitmap bitmap;
    Canvas canvas;
    private GyroscopeActivity.Mode mode = GyroscopeActivity.Mode.GYROSCOPE_ONLY;
    private OrientationFusedComplimentary orientationComplimentaryFusion;
    private OrientationFusedKalman orientationKalmanFusion;

    private MeanFilter meanFilter;
    int check = 0;

    //    chotu
    double marginX =1079.0;
    double marginY = 1788.0;

    //    PJ
//    double marginX = 1039.5442;
//    double marginY = 1991.0781;
//    double marginX = 695.91797;
//    double marginY = 1313.623;
//    Pixel
//    double marginX = 1073.93;
//    double marginY = 1572.8906;
// Joshi
//    double marginX = 1069.0101;
//    double marginY = 1840.0676;
//    Mittal
//    double marginX = 714.0;
//    double marginY = 1233.0;

    float initialX = 0;
    float initialY = 0;
    float finalX = 0;
    float finalY = 0;
    float currentX = 0;
    float currentY = 0;
    float stepLength = 75;
    float newX = 0;
    float newY = 0;
    float previousX = 0;
    float previousY = 0;

    //    bluetooth
    int path =1;
    int floor =1;
    private BluetoothManager btManager;
    private BluetoothAdapter btAdapter;
    private Handler scanHandler = new Handler();
    private int scan_interval_ms = 5000;
    private boolean isScanning = false;
    private DataLoggerManager dataLogger;
    private boolean meanFilterEnabled;
    private SensorManager sensorManager;
    private float[] fusedOrientation = new float[3];
    private float[] acceleration = new float[4];
    private float[] magnetic = new float[3];
    private float[] rotation = new float[3];
    //    wifi
    private WifiManager wifiManager;
    private List<ScanResult> results;
    private ArrayList<String> arrayList = new ArrayList<>();
    private ArrayAdapter adapter;
    public String SSID;
    public String level;
    public String str;
    boolean startWalk = false;
    public Sensor acce;
    public Sensor gyro1;
    public float confi_thresold = (float) ((float) 4.3 * Math.pow(10,-40));
    float tempX;
    float tempY;
    public float tempPrevY;
    public float tempPrevX;
    boolean pointer =false;

    private Sensor mag ;
    double angle1=0;
    double angle2 = 0;
    double net=0;
    float prev2 = 0;
    int i1=0;
    int point = 0;
    double height = 1.82;
    float freq = (float) 1.79;
    Timer timer = new Timer();
    long prev1 = 0;
    int flaw= 0;
    //north
    double northInc = 0;
    double preva = 0;

    //    magneto
    private Sensor accel;

    double angle_value=0;
    boolean changeInRouter = false;
    //    net array
    Queue<float[]> netQueue = new LinkedList<float[]>();

    //    pedometer list
    Queue<Pair<Float,Float>> pedoQueue  = new LinkedList<Pair<Float,Float>>();
    private float[] axis = new float[3];

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);
        }
        mContext = getApplicationContext();
        mResources = getResources();
        mRelativeLayout = (RelativeLayout) findViewById(R.id.rl);
        start = (Button) findViewById(R.id.start);
        dataLogger = new DataLoggerManager(this);
        start.setOnClickListener(this);
        end = (Button) findViewById(R.id.end);
        end.setOnClickListener(this);
        calib = (Button) findViewById(R.id.calib);
        calib.setOnClickListener(this);
        startLocating = (Button) findViewById(R.id.startLocating);
        startLocating.setOnClickListener(this);
        stopLocating = (Button) findViewById(R.id.stopLocating);
        stopLocating.setOnClickListener(this);
        reset= (Button) findViewById(R.id.reset);
        reset.setOnClickListener(this);
        mImageView = (ImageView) findViewById(R.id.iv);
        currentY = initialY;
        currentX = initialX;
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mImageView.setEnabled(false);
        Bitmap mutableBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.floor);
        bitmap = mutableBitmap.copy(Bitmap.Config.ARGB_8888, true);
        canvas = new Canvas(bitmap);
        mImageView.setImageBitmap(bitmap);
//        String[] coordi = {"0.389570068","0.74752555"};
////
//        Double varX = Double.valueOf(bitmap.getWidth());
//        Double varY = Double.valueOf(bitmap.getHeight());
//
//        System.out.println(bitmap.getWidth()+"_"+bitmap.getHeight()+"_"+varX+"_"+varY);
//        System.out.println("Start coordinates : \"" +Float.parseFloat(coordi[0]) + "\",\"" + Float.parseFloat(coordi[1])+"\"");
//
//        float markX1 = (float) (Double.parseDouble(coordi[0])*varX);
//        float markY1 = (float) (Double.parseDouble(coordi[1])*varY);
//        System.out.println("Start coordinates : \"" +markX1 + "\",\"" +markY1+"\"");
//
//        Paint paint = new Paint();
//        paint.setColor(Color.BLACK);
//        paint.setStyle(Paint.Style.FILL);
//        currentX = markX1;
//        currentY = markY1;
//        canvas.drawCircle(markX1,markY1, 24, paint);
//        mImageView.setImageBitmap(bitmap);
//
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        if (!wifiManager.isWifiEnabled()) {
            Toast.makeText(this, "WiFi is disabled ... We need to enable it", Toast.LENGTH_LONG).show();
            wifiManager.setWifiEnabled(true);
        }

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        streakPrevTime = System.currentTimeMillis() - 500;
        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {
            acce = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sensorManager.registerListener(this, acce, SensorManager.SENSOR_DELAY_UI);
        } else {
            Log.d("Fail","No accelerometer");
        }
        if (sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null) {

            gyro1 = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            sensorManager.registerListener(this, gyro1, 100000);
        } else {
            Log.d("Fail","No gyroscope");
        }


//        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
//        if (sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) != null) {
//            angle = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
//            sensorManager.registerListener(this, angle, SensorManager.SENSOR_DELAY_UI);
//        } else {
//            Log.d("Fail","No accelerometer");
//        }
//        streakPrevTime = System.currentTimeMillis() - 500;

        btManager = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = btManager.getAdapter();
        // Get an instance of the SensorManager
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) != null) {
            mag = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
            sensorManager.registerListener(this, mag, SensorManager.SENSOR_DELAY_UI);
        } else {
            Log.d("Fail","No accelerometer");
        }

    }

    private Runnable scanRunnable = new Runnable()
    {
        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
        @Override
        public void run() {
            btAdapter.startLeScan(leScanCallback);
            System.out.println("************scaning");
            scanHandler.postDelayed(this, scan_interval_ms);
            btAdapter.stopLeScan(leScanCallback);
            System.out.println("************stopping");
        }
    };
    private BluetoothAdapter.LeScanCallback leScanCallback = new BluetoothAdapter.LeScanCallback()
    {
        @Override
        public void onLeScan(final BluetoothDevice device, final int rssi, final byte[] scanRecord)
        {
            int startByte = 2;
            boolean patternFound = false;
            while (startByte <= 5)
            {
                if (    ((int) scanRecord[startByte + 2] & 0xff) == 0x02 && //Identifies an iBeacon
                        ((int) scanRecord[startByte + 3] & 0xff) == 0x15)
                {
                    patternFound = true;
                    break;
                }
                startByte++;
            }

            if (patternFound)
            {
                byte[] uuidBytes = new byte[16];
                System.arraycopy(scanRecord, startByte + 4, uuidBytes, 0, 16);
                String hexString = bytesToHex(uuidBytes);
                String uuid =  hexString.substring(0,8) + "-" +
                        hexString.substring(8,12) + "-" +
                        hexString.substring(12,16) + "-" +
                        hexString.substring(16,20) + "-" +
                        hexString.substring(20,32);
                final int major = (scanRecord[startByte + 20] & 0xff) * 0x100 + (scanRecord[startByte + 21] & 0xff);
                final int minor = (scanRecord[startByte + 22] & 0xff) * 0x100 + (scanRecord[startByte + 23] & 0xff);
                arrayList.add(major+"_"+minor+"+"+rssi);

//                arrayList.add(uuid+major+minor+","+rssi);
                Log.i("TAG","UUID: " +uuid + "\\nmajor: " +major +"\\nminor" +minor+"rssi"+rssi);
            }
        }
    };

    static final char[] hexArray = "0123456789ABCDEF".toCharArray();
    private static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for ( int j = 0; j < bytes.length; j++ ) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
        }
        else {
            Toast.makeText(MainActivity.this, "error", Toast.LENGTH_SHORT).show();
        }
    }
    protected void onResume() {
        super.onResume();
        switch (mode) {
            case GYROSCOPE_ONLY:
                orientationGyroscope = new OrientationGyroscope();
                break;
            case COMPLIMENTARY_FILTER:
                orientationComplimentaryFusion = new OrientationFusedComplimentary();
                break;
            case KALMAN_FILTER:
                orientationKalmanFusion = new OrientationFusedKalman();
                break;
        }
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, acce,SensorManager.SENSOR_DELAY_UI );
//        sensorManager.registerListener(this,
//                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
//                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, gyro1,SensorManager.SENSOR_DELAY_UI );
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),
                SensorManager.SENSOR_DELAY_NORMAL);

    }

    protected void onPause() {
        super.onPause();
//        sensorManager.unregisterListener(this);
    }
    @TargetApi(Build.VERSION_CODES.N)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    private void handleEvent(SensorEvent event) {
        if(pointer ==false) {
            return;
        }
        if (startWalk) {
            prev = lowPassFilter(event.values, prev);
            Accelerometer data = new Accelerometer(prev);
            if (data.R > 10.2f) {
                CURRENT_STATE = ABOVE;
                Toast.makeText(this, "STEPPPP!!!!!", Toast.LENGTH_SHORT).show();
                if (PREVIOUS_STATE != CURRENT_STATE) {
                    streakStartTime = System.currentTimeMillis();
//                if ((streakStartTime - streakPrevTime) <= 350f) {
//                    streakPrevTime = System.currentTimeMillis();
//                    return;
//                }
                    streakPrevTime = streakStartTime;

                    stepCount++;
                    System.out.println("ss:" + stepCount);
                    System.out.println(mAzimuth);
                    stepLength = (float) (60 * (0.7 + 0.371 * (height - 1.75) + 0.227 * (freq - 1.79) * height / 1.75));
                    float ang = (float) (mAzimuth - northInc);

                    if (Math.abs(ang - prev2) < 5 && stepCount != 1 && stepCount != 0) {
                        ang = prev2;
                    }
//                if(Math.abs(ang - prev2)>30 && Math.abs(ang - prev2)<60 && stepCount!=1 && stepCount!=0)
//                {
//                    if(ang - prev2>0)
//                        ang =45;
//                    else
//                        ang=-45;
//                }
//
//                if(Math.abs(ang - prev2)>75 && Math.abs(ang - prev2)<105 && stepCount!=1 && stepCount!=0)
//                {
//                    if(ang - prev2>0)
//                        ang =90;
//                    else
//                        ang=-90;
//                }

                    currentX = currentX + (stepLength * ((float) Math.sin((ang) * 3.14 / 180)));
                    currentY = currentY - (stepLength * ((float) Math.cos((ang) * 3.14 / 180)));
                    prev2 = ang;
                    if (stepCount % 3 == 0) {
                        final long fin = System.currentTimeMillis();
                        if (stepCount != 0) {
                            final float time = fin - prev1;

                            freq = 3 * 1000 / (time);
                            Toast.makeText(this, "freq " + freq + " " + time, Toast.LENGTH_SHORT).show();

                        }
                        prev1 = fin;
                    }
                    if (stepCount == 1 && point == 0) {
                        if (finalX != initialX) {
                            if (finalX > initialX) {
//                                System.out.println("Lmaooooo");
                                float slope1 = (currentY - initialY) / (currentX - initialX);
                                float slope2 = (finalY - initialY) / (finalX - initialX);
                                northInc = Math.atan(slope1);
                                northInc = northInc * 180 / Math.PI;
                                if(currentX<initialX)
                                {
                                    northInc = 180+northInc;
                                }
                                Toast.makeText(this, "Calibrated, Now press reset button1", Toast.LENGTH_SHORT).show();

//                        flaw = 1;
                            } else {
                                float slope1 = (currentY - initialY) / (currentX - initialX);
                                float slope2 = (finalY - initialY) / (finalX - initialX);
                                northInc = Math.atan(slope1);
                                northInc = (northInc * 180 / Math.PI);
                                if(currentX>initialX)
                                {
                                    northInc = -(180-northInc);
                                }
                                Toast.makeText(this, "Calibrated, Now press reset button2", Toast.LENGTH_SHORT).show();
                            }
                            currentX = currentX + (stepLength * ((float) Math.sin((mAzimuth - northInc) * 3.14 / 180)));
                            currentY = currentY - (stepLength * ((float) Math.cos((mAzimuth - northInc) * 3.14 / 180)));
                        } else {
//                            System.out.println("Lmaooooo");
                            if (finalY > initialY) {
                                float slope1 = (float) Math.atan((currentY - initialY) / (currentX - initialX));
                                northInc = -(90 - slope1 * 180 / Math.PI);
                                Toast.makeText(this, "Calibrated, Now press reset button!!!!3 " + northInc, Toast.LENGTH_SHORT).show();


//                            flaw = 2;
                            } else {
                                float slope1 = (float) Math.atan((currentY - initialY) / (currentX - initialX));
                                northInc = (90 - Math.abs(slope1 * 180 / Math.PI));
                                Toast.makeText(this, "Calibrated, Now press reset button!!!4 " + northInc, Toast.LENGTH_SHORT).show();
                            }
                            currentX = currentX + (stepLength * ((float) Math.sin((mAzimuth - northInc) * 3.14 / 180)));
                            currentY = currentY - (stepLength * ((float) Math.cos((mAzimuth - northInc) * 3.14 / 180)));
                        }
                    }
                    Paint paint = new Paint();
                    paint.setColor(Color.BLACK);
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(currentX, currentY, 20, paint);
                    mImageView.setImageBitmap(bitmap);
                    System.out.println("*********" + currentX + "," + currentY + "," + mAzimuth + "*********");
//                Toast.makeText(this,currentX+","+currentY+"step:"+stepCount+","+mAzimuth+","+ Math.sin(mAzimuth),Toast.LENGTH_SHORT).show();
                }
                PREVIOUS_STATE = CURRENT_STATE;
            } else if (data.R < 10.2f) {
                CURRENT_STATE = BELOW;
                PREVIOUS_STATE = CURRENT_STATE;
            }
        }
    }

    public float getXandY(String serverOut,int i){
        String[] coordi = serverOut.split(",");
        return Float.parseFloat(coordi[i]);
//        return 0;

    }
    private float[] lowPassFilter(float[] input, float[] prev) {
        float ALPHA = 0.1f;
        if(input == null || prev == null) {
            return null;
        }
        for (int i=0; i< input.length; i++) {
            prev[i] = prev[i] + ALPHA * (input[i] - prev[i]);
        }
        return prev;
    }
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @SuppressLint("SetTextI18n")
    @Override
    public void onSensorChanged(SensorEvent event) {

        switch(event.sensor.getType()){

            case Sensor.TYPE_MAGNETIC_FIELD:
//                System.out.println(event.values[0]+" "+event.values[1]+" "+event.values[2]);
                if(event.values[1]>0)
                {
                    angle_value = 90 - (Math.atan(event.values[0]/event.values[1]))*180;
                }
                if(event.values[1]<0)
                {
                    angle_value = 270 - (Math.atan(event.values[0]/event.values[1]))*180;
                }
                if(event.values[1]==0 && event.values[0]<0)
                {
                    angle_value = 180;
                }
                if(event.values[1]==0 && event.values[0]>0)
                {
                    angle_value = 0;
                }
                net = Math.sqrt(event.values[0]*event.values[0]+event.values[1]*event.values[1]+event.values[2]*event.values[2]);
                axis = event.values;
                break;
            case Sensor.TYPE_ACCELEROMETER:
                handleEvent(event);
                System.arraycopy(event.values, 0, acceleration, 0, event.values.length);
                hasAcceleration = true;
                if(SAMPLING_ACTIVE) {
                    sampleCount++;
                    long now = System.currentTimeMillis();
                    if (now >= startTime + 3000) {
                        double samplingRate = sampleCount / ((now - startTime) / 1000.0);
                        SAMPLING_ACTIVE = false;
                    }
                }
                break;

            case Sensor.TYPE_GYROSCOPE:

                // Android reuses events, so you probably want a copy
                System.arraycopy(event.values, 0, rotation, 0, event.values.length);

                switch (mode) {
                    case GYROSCOPE_ONLY:
                        if(!orientationGyroscope.isBaseOrientationSet()) {
                            orientationGyroscope.setBaseOrientation(Quaternion.IDENTITY);
                        } else {
                            fusedOrientation = orientationGyroscope.calculateOrientation(rotation, event.timestamp);
                        }
//                            System.out.println("****"+fusedOrientation[2]*180/Math.PI);
//                            Toast.makeText(this,fusedOrientation[2]*180/Math.PI+" ",Toast.LENGTH_SHORT).show();
                        mAzimuth  = fusedOrientation[2]*180/Math.PI;
                        break;
                    case COMPLIMENTARY_FILTER:
                        if(!orientationComplimentaryFusion.isBaseOrientationSet()) {
                            if(hasAcceleration && hasMagnetic) {
                                orientationComplimentaryFusion.setBaseOrientation(RotationUtil.getOrientationVectorFromAccelerationMagnetic(acceleration, magnetic));
                            }
                        } else {
                            fusedOrientation = orientationComplimentaryFusion.calculateFusedOrientation(rotation, event.timestamp, acceleration, magnetic);
                            Log.d("kbk", "Process Orientation Fusion Complimentary: " + Arrays.toString(fusedOrientation));
                        }
                        mAzimuth  = fusedOrientation[2]*180/Math.PI;
                        break;
                    case KALMAN_FILTER:

                        if(!orientationKalmanFusion.isBaseOrientationSet()) {
                            if(hasAcceleration && hasMagnetic) {
                                orientationKalmanFusion.setBaseOrientation(RotationUtil.getOrientationVectorFromAccelerationMagnetic(acceleration, magnetic));
                            }
                        } else {
                            fusedOrientation = orientationKalmanFusion.calculateFusedOrientation(rotation, event.timestamp, acceleration, magnetic);
                        }
                        mAzimuth  = fusedOrientation[2]*180/Math.PI;
                        break;
                }

                if(meanFilterEnabled) {
                    fusedOrientation = meanFilter.filter(fusedOrientation);
                    mAzimuth  = fusedOrientation[2]*180/Math.PI;
                }
                dataLogger.setRotation(fusedOrientation);
                mAzimuth  = fusedOrientation[2]*180/Math.PI;

                break;
        }}


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.start: {
                mImageView.setEnabled(true);
                startWalk = true;
                MyTimer();
//                mImageView.setOnTouchListener(new View.OnTouchListener() {
//                    @Override
//                    public boolean onTouch(View v, MotionEvent event) {
//                        if (event.getAction() == MotionEvent.ACTION_DOWN){
//                            Paint paint = new Paint();
//                            paint.setColor(Color.RED);
//                            paint.setStyle(Paint.Style.FILL);
//                            float varX = (float) (bitmap.getWidth()/marginX);
//                            float varY = (float) (bitmap.getHeight()/marginY);
//                            canvas.drawCircle((event.getX())*varX,(event.getY())*varY, 20, paint);
//                            initialX = event.getX()*varX;
//                            initialY = (event.getY())*varY;
//                            currentX = event.getX()*varX;
//                            currentY = (event.getY())*varY;
//                            System.out.println("Start coordinates : " +event.getX() + "x" + event.getY());
//
//                            mImageView.setImageBitmap(bitmap);
//                        }
//                        mImageView.setEnabled(false);
//                        if(point==0) {
//                            end.setVisibility(View.VISIBLE);
//                        }
//                        else
//                        {
//                            startLocating.setVisibility(View.VISIBLE);
//                        }
//                        return true;
//                    }
//                });
                start.setVisibility(View.INVISIBLE);
                stopLocating.setVisibility(View.VISIBLE);
                break;
            }

            case R.id.end:{
                System.out.println("here");
                mImageView.setEnabled(true);

                mImageView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        if (event.getAction() == MotionEvent.ACTION_DOWN){
                            Paint paint = new Paint();
                            paint.setColor(Color.BLUE);
                            paint.setStyle(Paint.Style.FILL);
                            float varX = (float) (bitmap.getWidth() / marginX);
                            float varY = (float) (bitmap.getHeight() / marginY);

                            finalX = event.getX() * varX;
                            finalY = (event.getY()) * varY;

                            if (Math.abs(finalX - initialX) < Math.abs(finalY - initialY)) {
                                finalX = initialX;
                            }
                            else
                            {
                                finalY=initialY;
                            }
//                                canvas.drawCircle((event.getX())*varX,(event.getY())*varY, 20, paint);

                            canvas.drawCircle(finalX,finalY, 20, paint);
                            System.out.println("End coordinates : " +finalX + "x" + finalY);

                            mImageView.setImageBitmap(bitmap);
                            calib.setVisibility(View.VISIBLE);
                        }
                        mImageView.setEnabled(false);
                        return true;
                    }
                });
                end.setVisibility(View.INVISIBLE);
                break;
            }
            case R.id.startLocating:{
                pointer = true;
                if(point==0)
                {
                    Toast.makeText(this,"Move step along the selected path",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(this, "Start walking...", Toast.LENGTH_SHORT).show();
                }
                startLocating.setVisibility(View.INVISIBLE);
                sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
                if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {
                    acce = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                    sensorManager.registerListener(this, acce, SensorManager.SENSOR_DELAY_UI);
                } else {
                    Log.d("Fail","No accelerometer");
                }
                if (sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null) {
                    gyro1 = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
                    sensorManager.registerListener(this, gyro1, SensorManager.SENSOR_DELAY_UI);
                } else {
                    Log.d("Fail","No accelerometer");
                }
                streakPrevTime = System.currentTimeMillis() - 500;
                if(point==0)
                {
                    reset.setVisibility(View.VISIBLE);

                }
                else {
                    stopLocating.setVisibility(View.VISIBLE);
                }
                startWalk = true;
                Toast.makeText(this,"Start walking...",Toast.LENGTH_SHORT).show();
                btAdapter.startLeScan(leScanCallback);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                startTimer = System.nanoTime();
                MyTimer();
                break;
            }

            case R.id.stopLocating:{
                pointer = false;
                btAdapter.stopLeScan(leScanCallback);
                startWalk = false;
                stopLocating.setVisibility(View.INVISIBLE);
                reset.setVisibility(View.VISIBLE);
                System.out.println("Stopped!");
                break;
            }

            case R.id.calib:{
                calib.setVisibility(View.INVISIBLE);
                pointer = true;
                if(point==0)
                {
                    Toast.makeText(this,"Move step along the selected path",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(this, "Start walking...", Toast.LENGTH_SHORT).show();
                }
                startLocating.setVisibility(View.INVISIBLE);
                sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
                if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {
                    acce = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                    sensorManager.registerListener(this, acce, SensorManager.SENSOR_DELAY_UI);
                } else {
                    Log.d("Fail","No accelerometer");
                }
                if (sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null) {
                    gyro1 = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
                    sensorManager.registerListener(this, gyro1, SensorManager.SENSOR_DELAY_UI);
                } else {
                    Log.d("Fail","No accelerometer");
                }
                streakPrevTime = System.currentTimeMillis() - 500;
                if(point==0)
                {
                    reset.setVisibility(View.VISIBLE);

                }
                else {
                    stopLocating.setVisibility(View.VISIBLE);
                }
                startWalk = true;
                Toast.makeText(this,"Start walking...",Toast.LENGTH_SHORT).show();
                btAdapter.startLeScan(leScanCallback);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                startTimer = System.nanoTime();
                break;
            }

            case R.id.reset:{
                if(point==0)
                {
                    pointer=false;
                    check=1;
                    point=1;
                }

                stepCount = 2;
                reset.setVisibility(View.INVISIBLE);
                start.setVisibility(View.VISIBLE);
                Bitmap mutableBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.floor);
                bitmap = mutableBitmap.copy(Bitmap.Config.ARGB_8888, true);
                canvas = new Canvas(bitmap);
                mImageView.setImageBitmap(bitmap);
                break;
            }
        }
    }


    private void scanWifi() {
        tempX = currentX;
        tempY = currentY;
        tempPrevX = previousX;
        tempPrevY = previousY;
        registerReceiver(wifiReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        wifiManager.startScan();
        Log.d("results","xlll");
    }

    public float[] ema(Queue<float[]> input){
        Queue<float[]> temp = new LinkedList<>(input);
        float[] avg = new float[3];
        int i=0;
        while (temp.size()>1){
            avg[0] = (float) (avg[0] + temp.peek()[0] * 0.1);
            avg[1] = (float) (avg[1] + temp.peek()[1] * 0.1);
            avg[2] = (float) (avg[2] + temp.peek()[2] * 0.1);
            temp.remove();
            i++;
        }
        if(temp.size()==1){
            avg[0] = (float) (avg[0] + temp.peek()[0]*0.9);
            avg[1] = (float) (avg[1] + temp.peek()[1]*0.9);
            avg[2] = (float) (avg[2] + temp.peek()[2]*0.9);
        }
        if (input.size()==0){
            System.out.println("zero");
            float[] zeros = new float[3];
            return zeros;
        }
        return (avg);
    }

    BroadcastReceiver wifiReceiver = new BroadcastReceiver() {
        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public void onReceive(Context context, Intent intent) {
            results = wifiManager.getScanResults();
            unregisterReceiver(this);

            Log.d("results","x"+results.size());
            int bluetoothCount = arrayList.size();
            for (ScanResult scanResult : results) {
                arrayList.add(scanResult.SSID + "," + scanResult.level);
                System.out.println(scanResult.SSID + "," + scanResult.level);

            }
            int wificount = arrayList.size() - bluetoothCount;
            String collect = arrayList.stream().collect(Collectors.joining(","));
            str = "hey yo,"+bluetoothCount+","+wificount+","+net+","+collect;
//            str = "hey yo,"+bluetoothCount+","+collect+","+currentX+","+currentY;
            Client client;
            try {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);

                client = new Client("172.23.55.232", 3000, str);
                System.out.println("String returned: "+client.getString());
//                            need to draw the circle

                String[] coordi = client.getString().split(",");

                float markX1 = Float.parseFloat(coordi[0]);
                float markY1 = Float.parseFloat(coordi[1]);


                Paint paint = new Paint();
                paint.setColor(Color.YELLOW);
                paint.setStyle(Paint.Style.FILL);
                currentX = markX1;
                currentY = markY1;
                canvas.drawCircle(markX1,markY1, 24, paint);
                mImageView.setImageBitmap(bitmap);

                markX1 = Float.parseFloat(coordi[4]);
                markY1 = Float.parseFloat(coordi[5]);

                paint = new Paint();
                paint.setColor(Color.RED);
                paint.setStyle(Paint.Style.FILL);
//                currentX = markX1;
//                currentY = markY1;
                canvas.drawCircle(markX1,markY1, 20, paint);
                mImageView.setImageBitmap(bitmap);

                markX1 = Float.parseFloat(coordi[7]);
                markY1 = Float.parseFloat(coordi[8]);

                paint = new Paint();
                paint.setColor(Color.GREEN);
                paint.setStyle(Paint.Style.FILL);
//                currentX = markX1;
//                currentY = markY1;
                canvas.drawCircle(markX1,markY1, 15, paint);
                mImageView.setImageBitmap(bitmap);

            } catch (IOException e) {
                System.out.println(e);
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                System.out.println(e);
                e.printStackTrace();
            }
        }

    };

    public float[] nearest_point(String input, float x, float y){
        String[] split_array = input.split(",");
        float[] dist = new float[3];
        for (int i=0;i<3;i=i+1){
            dist[i] = distanceBtwnPoints( Float.valueOf(split_array[(2*i)+1]), Float.valueOf(split_array[2*i+2]),x,y);
        }

        int maxi = 0;
        float max_dis = dist[0];
        for (int i=0;i<3;i++){
            if (max_dis < dist[i]){
                max_dis = dist[i];
                maxi = i;
            }
        }
        float[] ans = {Float.valueOf(split_array[maxi + 1]), Float.valueOf(split_array[maxi + 2])};
        return ans;
    }
    public float distanceBtwnPoints(float xa, float ya, float xb, float yb){
        return (float) Math.sqrt(Math.pow(xa-xb,2)+Math.pow(ya-yb,2));
    }
    private void Submit(String SSID1,String level1 )
    {
        SSID = SSID1;
        level = level1;

        String URL="http://172.23.92.113:3000/users";

//        final String finalSSID = SSID;
//        final String finalLevel = level;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(MainActivity.this,response,Toast.LENGTH_LONG).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this,error.toString(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<String, String>();

                params.put("name", SSID);
                params.put("value", level);
                System.out.println("*********"+params+"*********");
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        requestQueue.add(stringRequest);
    }

    public void MyTimer() {

        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
//            private final int MAX_SECONDS = 10;

            int seconds = 0;
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
            @Override
            public void run() {
                if (startWalk) {
//
                    Client client;
                    try {
                        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                        StrictMode.setThreadPolicy(policy);

                        if (netQueue.size() == 2){
                            netQueue.remove();
                            netQueue.add(axis);
                        }
                        else {
                            netQueue.add(axis);
                        }

                        previousX = newX;
                        previousY = newY;
                        Double varX = Double.valueOf(((bitmap.getWidth())));
                        Double varY = Double.valueOf(((bitmap.getHeight())));
                        float[] tempOut = ema(netQueue);
                        client = new Client("172.23.9.4", 3000,"Innov 4.0"+","+floor+","+path+","+currentX/varX+","+currentY/varY+","+tempOut[0]+","+tempOut[1]+","+tempOut[2]);
//                        client = new Client("172.23.54.61", 3002,"Innov 4.0"+","+floor+","+path+","+currentX/varX+","+currentY/varY+","+ema(netQueue)+","+arrayList.stream().collect(Collectors.joining("$"))); // need to change ip
                        System.out.println("String returned: "+client.getString());
//                            need to draw the circle

                        String[] coordi = client.getString().split(",");
                        if (coordi.length == 3){
                            float markX1 = (float) (Double.parseDouble(coordi[1])*varX);
                            float markY1 = (float) (Double.parseDouble(coordi[2])*varY);
                            System.out.println("Start coordinates : \"" +markX1 + "\",\"" +markY1+"\"");

                            newX = markX1;
                            newY = markY1;
                            if (Math.abs(newX-previousX)<0.001 && Math.abs(newY-previousY)<0.001 ){
                                changeInRouter = false;
                            }
                            else {
                                changeInRouter = true;
                                currentX = newX;
                                currentY = newY;
                            }

                            System.out.println("__-__-__-"+(previousX-newX)+","+previousY+","+newX+","+newY+","+currentX+","+currentY);
                            Paint paint = new Paint();
                            paint.setColor(Color.RED);
                            paint.setStyle(Paint.Style.FILL);
                            canvas.drawCircle(markX1,markY1, 24, paint);
                            mImageView.setImageBitmap(bitmap);
                        }
                        else {
                            if(Integer.parseInt(coordi[0])<=0){
                                float markX1 = (float) (Double.parseDouble(coordi[1])*varX);
                                float markY1 = (float) (Double.parseDouble(coordi[2])*varY);
                                System.out.println("Start coordinates : \"" +markX1 + "\",\"" +markY1+"\"");

                                newX = markX1;
                                newY = markY1;
                                if (Math.abs(newX-previousX)<0.001 && Math.abs(newY-previousY)<0.001 ){
                                    changeInRouter = false;
                                }
                                else {
                                    changeInRouter = true;
                                    currentX = newX;
                                    currentY = newY;
                                }

                                System.out.println("__-__-__-"+(previousX-newX)+","+previousY+","+newX+","+newY+","+currentX+","+currentY);
                                Paint paint = new Paint();
                                paint.setColor(Color.BLACK);
                                paint.setStyle(Paint.Style.FILL);
                                canvas.drawCircle(markX1,markY1, 24, paint);
//                                for (int i=3;i<coordi.length;i=i+2){
//                                    float tempM1 = (float) (Double.parseDouble(coordi[i])*varX);
//                                    float tempM2 = (float) (Double.parseDouble(coordi[i+1])*varY);
//                                    Paint paintT = new Paint();
//                                    if (i==3)   paintT.setColor(Color.RED);
//                                    else  paintT.setColor(Color.BLUE);
//                                    paintT.setStyle(Paint.Style.FILL);
//                                    canvas.drawCircle(markX1,markY1, 24, paintT);
//                                }
                                mImageView.setImageBitmap(bitmap);
                            }
                            else {
                                float markX1 = (float) (Double.parseDouble(coordi[5])*varX);
                                float markY1 = (float) (Double.parseDouble(coordi[6])*varY);
                                System.out.println("Start coordinates : \"" +markX1 + "\",\"" +markY1+"\"");

                                newX = markX1;
                                newY = markY1;
                                if (Math.abs(newX-previousX)<0.001 && Math.abs(newY-previousY)<0.001 ){
                                    changeInRouter = false;
                                }
                                else {
                                    changeInRouter = true;
                                    currentX = newX;
                                    currentY = newY;
                                }

                                System.out.println("__-__-__-"+(previousX-newX)+","+previousY+","+newX+","+newY+","+currentX+","+currentY);
                                Paint paint = new Paint();
                                paint.setColor(Color.BLACK);
                                paint.setStyle(Paint.Style.FILL);
                                canvas.drawCircle(markX1,markY1, 24, paint);
//                                for (int i=1;i<(coordi.length-2);i=i+2){
//                                    float tempM1 = (float) (Double.parseDouble(coordi[i])*varX);
//                                    float tempM2 = (float) (Double.parseDouble(coordi[i+1])*varY);
//                                    Paint paintT = new Paint();
//                                    if (i==3)   paintT.setColor(Color.RED);
//                                    else  paintT.setColor(Color.BLUE);
//                                    paintT.setStyle(Paint.Style.FILL);
//                                    canvas.drawCircle(markX1,markY1, 24, paintT);
//                                }
                                mImageView.setImageBitmap(bitmap);
                            }
                        }

                    } catch (IOException e) {
                        System.out.println(e);
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        System.out.println(e);
                        e.printStackTrace();
                    }
                    arrayList.clear();

//
                } else {
                    // stop the timer
                    cancel();
                }
            }
        };
        timer.schedule(task, 0, 3000);

    }
}


class Client
{
    // initialize socket and input output streams
    private Socket socket = null;
    private DataOutputStream outdata  ;
    private DataInputStream serverOut ;
    private String receivedData;
    OutputStreamWriter osw;

    // constructor to put ip address and port

    public Client(String address, int port, String inStr) throws IOException, ClassNotFoundException {
        // establish a connection
        try
        {
            socket = new Socket(address, port);
            System.out.println("Connected");
            System.out.println(inStr);
            osw =new OutputStreamWriter(socket.getOutputStream(), "UTF-8");
            outdata    = new DataOutputStream(socket.getOutputStream());

        }
        catch(SocketException u)
        {
            System.out.println(u);
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
        try
        {
            osw.write(inStr, 0, inStr.length());
            osw.flush();
//            outdata.writeUTF(inStr);
//            outdata.flush();
//            outdata.writeUTF(inStr);
        }
        catch(IOException i)
        {
            System.out.println(i);
        }


        serverOut = new DataInputStream(socket.getInputStream());

        BufferedReader in = new BufferedReader( new InputStreamReader(socket.getInputStream()));

        String line="";
        try
        {
            line = in.readLine();
            receivedData = line;
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
        // close the connection
        try
        {
            osw.close();
            outdata.close();
            socket.close();
            serverOut.close();
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
    }
    String getString(){
        return receivedData;
    }


}

