package com.example.maps_steps;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity implements SensorEventListener, View.OnClickListener {

//    private TextView steps;
    private SensorManager sensorManager;
    private Sensor angle;
    public int count=0;
    public float inclination =0;
    private int mAzimuth = 0;
    private float[] prev = {0f,0f,0f};
    private Menu menu;
    private TextView stepView;
    private int stepCount = 0;
    private static final int ABOVE = 1;
    private static final int BELOW = 0;
    private static int CURRENT_STATE = 0;
    private static int PREVIOUS_STATE = BELOW;
    private int sampleCount = 0;
    private long startTime;
    boolean SAMPLING_ACTIVE = true;
    private long streakStartTime;
    private long streakPrevTime;

    //maps
    private Context mContext;
    private Resources mResources;
    private RelativeLayout mRelativeLayout;
    private Button start;
    private Button end;
    private Button startLocating;
    private Button stopLocating;
    private Button reset;
    private Button pathButton;

    private ImageView mImageView;
    Bitmap bitmap;
    Bitmap initiaLbitmap;
    Canvas canvas;
    String currentStr="";
    String previousStr="";
//    PJ
//    double marginX = 1388.3151;
//    double marginY = 2675.2825;

//    chotu
    double marginX =1079.0;
    double marginY = 1788.0;

//    double marginX = 695.91797;
//    double marginY = 1313.623;
//    Pixel
//    double marginX = 1073.93;
//    double marginY = 1572.8906;
// Joshi
//    double marginX = 1069.0101;
//    double marginY = 1840.0676;
//    Mittal
//    double marginX = 714.0;
//    double marginY = 1233.0;

    float initialX = 0;
    float initialY = 0;
    double storeX = 0;
    double storeY = 0;
    float currentX = 0;
    float currentY = 0;
    float stepLength = 75;

    //    bluetooth
    int path = 1;
    int floor =1;
    private BluetoothManager btManager;
    private BluetoothAdapter btAdapter;
    private Handler scanHandler = new Handler();
    private int scan_interval_ms = 5000;

    private boolean isScanning = false;

//    wifi
    private WifiManager wifiManager;
    private List<ScanResult> results;
    private ArrayList<String> arrayList = new ArrayList<>();
    private ArrayAdapter adapter;
    public String SSID;
    public String level;
    public String str;
    boolean startWalk = false;

//    MAGNETOMETER
    private Sensor mag ;
    double net =0;
    double angle_value=0;

//    TIMER
    int seconds = 0;
    int period = 700;

//    net array

    private float[] axis = new float[3];
    Queue<float[]> netQueue = new LinkedList<float[]>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);
        }

        mContext = getApplicationContext();
        mResources = getResources();
        mRelativeLayout = (RelativeLayout) findViewById(R.id.rl);
        start = (Button) findViewById(R.id.start);

        start.setOnClickListener(this);
        end = (Button) findViewById(R.id.end);
        end.setOnClickListener(this);
        startLocating = (Button) findViewById(R.id.startLocating);
        startLocating.setOnClickListener(this);
        stopLocating = (Button) findViewById(R.id.stopLocating);
        stopLocating.setOnClickListener(this);
        reset= (Button) findViewById(R.id.reset);
        reset.setOnClickListener(this);
        pathButton= (Button) findViewById(R.id.path);
        pathButton.setOnClickListener(this);
        mImageView = (ImageView) findViewById(R.id.iv);
        currentY = initialY;
        currentX = initialX;

        mImageView.setEnabled(false);
        Bitmap mutableBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.floor);
//        Bitmap mutableBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.demo);
        bitmap = mutableBitmap.copy(Bitmap.Config.ARGB_8888, true);
        initiaLbitmap = bitmap;
//        bitmap = Bitmap.createBitmap(
//                500, // Width
//                300, // Height
//                Bitmap.Config.ARGB_8888 // Config
//        );
        canvas = new Canvas(bitmap);
        mImageView.setImageBitmap(bitmap);
//        steps = (TextView)findViewById(R.id.steps);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        if (!wifiManager.isWifiEnabled()) {
            Toast.makeText(this, "WiFi is disabled ... We need to enable it", Toast.LENGTH_LONG).show();
            wifiManager.setWifiEnabled(true);
        }

        btManager = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = btManager.getAdapter();

        // Get an instance of the SensorManager
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) != null) {
            mag = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
            sensorManager.registerListener(this, mag, SensorManager.SENSOR_DELAY_UI);
        } else {
            Log.d("Fail","No accelerometer");
        }

    }

    private Runnable scanRunnable = new Runnable()
    {
        @Override
        public void run() {
            btAdapter.startLeScan(leScanCallback);
            System.out.println("************scaning");
            scanHandler.postDelayed(this, scan_interval_ms);
            btAdapter.stopLeScan(leScanCallback);
            System.out.println("************stopping");
        }
    };
    private BluetoothAdapter.LeScanCallback leScanCallback = new BluetoothAdapter.LeScanCallback()
    {
        @Override
        public void onLeScan(final BluetoothDevice device, final int rssi, final byte[] scanRecord)
        {
            int startByte = 2;
            boolean patternFound = false;
            while (startByte <= 5)
            {
                if (    ((int) scanRecord[startByte + 2] & 0xff) == 0x02 && //Identifies an iBeacon
                        ((int) scanRecord[startByte + 3] & 0xff) == 0x15)
                {
                    patternFound = true;
                    break;
                }
                startByte++;
            }
//            Toast.makeText(MainActivity.this, "--------------> "+patternFound, Toast.LENGTH_SHORT).show();

//            System.out.println("--------------> "+patternFound);
            if (patternFound)
            {
                byte[] uuidBytes = new byte[16];
                System.arraycopy(scanRecord, startByte + 4, uuidBytes, 0, 16);
                String hexString = bytesToHex(uuidBytes);
                String uuid =  hexString.substring(0,8) + "-" +
                        hexString.substring(8,12) + "-" +
                        hexString.substring(12,16) + "-" +
                        hexString.substring(16,20) + "-" +
                        hexString.substring(20,32);
                final int major = (scanRecord[startByte + 20] & 0xff) * 0x100 + (scanRecord[startByte + 21] & 0xff);
                final int minor = (scanRecord[startByte + 22] & 0xff) * 0x100 + (scanRecord[startByte + 23] & 0xff);

                arrayList.add(major+"_"+minor+"+"+rssi);
//                Log.i("TAG","UUID: " +uuid + "\\nmajor: " +major +"\\nminor" +minor+"rssi"+rssi);
            }
        }
    };

    static final char[] hexArray = "0123456789ABCDEF".toCharArray();
    private static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for ( int j = 0; j < bytes.length; j++ ) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
        }
        else {
            Toast.makeText(MainActivity.this, "error", Toast.LENGTH_SHORT).show();
        }
    }
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this,
        sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),
        SensorManager.SENSOR_DELAY_NORMAL);

//        sensorManager.registerListener(this,
//                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
//                SensorManager.SENSOR_DELAY_NORMAL);
//        sensorManager.registerListener(this, angle,SensorManager.SENSOR_DELAY_UI );
    }

    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }
    private void handleEvent(SensorEvent event) {
//        if (startWalk){
//        prev = lowPassFilter(event.values,prev);
//        Accelerometer data = new Accelerometer(prev);
//        if(data.R > 10.07f){
//            CURRENT_STATE = ABOVE;
//            if(PREVIOUS_STATE != CURRENT_STATE) {
//                streakStartTime = System.currentTimeMillis();
//                if ((streakStartTime - streakPrevTime) <= 350f) {
//                    streakPrevTime = System.currentTimeMillis();
//                    return;
//                }
//                streakPrevTime = streakStartTime;
//
//                    stepCount++;
//                    Toast.makeText(this,"Step counted: "+mAzimuth,Toast.LENGTH_SHORT).show();
//                    currentX = currentX + (stepLength* ((float) Math.sin((mAzimuth-7)*3.14/180)));
//                    currentY = currentY  - (stepLength* ((float) Math.cos((mAzimuth-7)*3.14/180)));
//
////                    if ((stepCount%5)!=0){
//                    if (false){
//
//                        Paint paint = new Paint();
//                        paint.setColor(Color.RED);
//                        paint.setStyle(Paint.Style.FILL);
//                        canvas.drawCircle(currentX,currentY, 30, paint);
//                        mImageView.setImageBitmap(bitmap);
//
//                    }
//                    else{
//
//                        Paint paint = new Paint();
//                        paint.setColor(Color.BLACK);
//                        paint.setStyle(Paint.Style.FILL);
//                        canvas.drawCircle(currentX,currentY, 30, paint);
//                        mImageView.setImageBitmap(bitmap);
//                        btAdapter.startLeScan(leScanCallback);
//                        try {
//                            Thread.sleep(1000);
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
    //                        btAdapter.stopLeScan(leScanCallback);
//                        scanWifi();
//                        arrayList.clear();
//                    }
//
//                }
//            PREVIOUS_STATE = CURRENT_STATE;
//        }
//        else if(data.R < 10.07f) {
//            CURRENT_STATE = BELOW;
//            PREVIOUS_STATE = CURRENT_STATE;
//        }
//        }

    }

    private float[] lowPassFilter(float[] input, float[] prev) {
        float ALPHA = 0.1f;
        if(input == null || prev == null) {
            return null;
        }
        for (int i=0; i< input.length; i++) {
            prev[i] = prev[i] + ALPHA * (input[i] - prev[i]);
        }
        return prev;
    }
    @SuppressLint("SetTextI18n")
    @Override
    public void onSensorChanged(SensorEvent event) {

        switch(event.sensor.getType()){

            case Sensor.TYPE_MAGNETIC_FIELD:
//                System.out.println(event.values[0]+" "+event.values[1]+" "+event.values[2]);
                if(event.values[1]>0)
                {
                    angle_value = 90 - (Math.atan(event.values[0]/event.values[1]))*180;
                }
                if(event.values[1]<0)
                {
                    angle_value = 270 - (Math.atan(event.values[0]/event.values[1]))*180;
                }
                if(event.values[1]==0 && event.values[0]<0)
                {
                    angle_value = 180;
                }
                if(event.values[1]==0 && event.values[0]>0)
                {
                    angle_value = 0;
                }
                net = Math.sqrt(event.values[0]*event.values[0]+event.values[1]*event.values[1]+event.values[2]*event.values[2]);
                axis[0] = event.values[0];
                axis[1] = event.values[1];
                axis[2] = event.values[2];
                break;
            case Sensor.TYPE_ROTATION_VECTOR:
                float[] orientation = new float[3];
                float[] rMat = new float[9];
                SensorManager.getRotationMatrixFromVector( rMat, event.values );
                // get the azimuth value (orientation[0]) in degree
                mAzimuth = (int) ( Math.toDegrees( SensorManager.getOrientation( rMat, orientation )[0] ) + 360 ) % 360;
                break;

            case Sensor.TYPE_ACCELEROMETER:
                handleEvent(event);
                if(SAMPLING_ACTIVE) {
                    sampleCount++;
                    long now = System.currentTimeMillis();
                    if (now >= startTime + 5000) {
                        double samplingRate = sampleCount / ((now - startTime) / 1000.0);
                        SAMPLING_ACTIVE = false;
                    }
                }
                break;
        }
//        steps.setText(String.valueOf(mAzimuth)+" "+String.valueOf(stepCount));

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.start: {

//                startWalk = true;
//                MyTimer();
//                stopLocating.setVisibility(View.VISIBLE);
//                MyTimer();
                mImageView.setEnabled(true);
                mImageView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        if (event.getAction() == MotionEvent.ACTION_DOWN){
                            Paint paint = new Paint();
                            paint.setColor(Color.RED);
                            paint.setStyle(Paint.Style.FILL);
                            float varX = (float) (bitmap.getWidth()/marginX);
                            float varY = (float) (bitmap.getHeight()/marginY);
                            canvas.drawCircle((event.getX())*varX,(event.getY())*varY, 30, paint);
                            initialX = event.getX()*varX;
                            initialY = (event.getY())*varY;

                            currentX = event.getX()*varX;
                            currentY = (event.getY())*varY;

                            storeX = event.getX()/marginX;
                            storeY = event.getY()/marginY;
                            System.out.println(bitmap.getWidth()+"_"+bitmap.getHeight()+"_"+varX+"_"+varY);
                            System.out.println("Start coordinates : \"" +storeX + "\",\"" + storeY+"\"");
                            System.out.println("coordinates : "+event.getX()+","+event.getY());

                            mImageView.setImageBitmap(bitmap);
                        }
                        mImageView.setEnabled(false);
//                        end.setVisibility(View.VISIBLE);
                        startLocating.setVisibility(View.VISIBLE);
                        return true;
                    }
                });
                start.setVisibility(View.INVISIBLE);
                pathButton.setVisibility(View.INVISIBLE);

                break;
            }

            case R.id.path:{
                path++;
                break;
            }
            case R.id.end:{
                mImageView.setEnabled(true);

                mImageView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        if (event.getAction() == MotionEvent.ACTION_DOWN){
                            Paint paint = new Paint();
                            paint.setColor(Color.BLUE);
                            paint.setStyle(Paint.Style.FILL);
                            float varX = (float) (bitmap.getWidth()/marginX);
                            float varY = (float) (bitmap.getHeight()/marginY);
                            canvas.drawCircle((event.getX())*varX,(event.getY())*varY, 30, paint);
//                            finalX = event.getX()*varX;
//                            finalY = (event.getY())*varY;
//                            System.out.println("End coordinates : " +finalX + "x" + finalY);

                            mImageView.setImageBitmap(bitmap);
                            startLocating.setVisibility(View.VISIBLE);
                        }
                        mImageView.setEnabled(false);
                        return true;
                    }
                });
                end.setVisibility(View.INVISIBLE);
                break;
            }

            case R.id.startLocating:{
                startLocating.setVisibility(View.INVISIBLE);

                startWalk = true;

//                btAdapter.startLeScan(leScanCallback);
//                try {
//                    Thread.sleep(period);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
                MyTimer();
                stopLocating.setVisibility(View.VISIBLE);

//                walking
//                sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
//                if (sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) != null) {
//                    angle = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
//                    sensorManager.registerListener(this, angle, SensorManager.SENSOR_DELAY_UI);
//                } else {
//                    Log.d("Fail","No accelerometer");
//                }
//                streakPrevTime = System.currentTimeMillis() - 500;

                break;
            }

            case R.id.stopLocating:{
                btAdapter.stopLeScan(leScanCallback);
                startWalk = false;
                stopLocating.setVisibility(View.INVISIBLE);
                start.setVisibility(View.VISIBLE);
                pathButton.setVisibility(View.VISIBLE);
//                reset.setVisibility(View.VISIBLE);
                arrayList.clear();
                System.out.println("Stopped!");
//                Paint paint = new Paint();
//                paint.setColor(Color.BLACK);
//                paint.setStyle(Paint.Style.FILL);
//                canvas.drawLine(initialX,initialY,finalX,finalY,paint);
//                mImageView.setImageBitmap(bitmap);
                break;
            }

            case R.id.reset:{
                stepCount = 0;
                reset.setVisibility(View.INVISIBLE);
                start.setVisibility(View.VISIBLE);
                pathButton.setVisibility(View.VISIBLE);

                Bitmap mutableBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.floor);
                bitmap = mutableBitmap.copy(Bitmap.Config.ARGB_8888, true);
                canvas = new Canvas(bitmap);
                mImageView.setImageBitmap(bitmap);
//                mImageView.setImageBitmap(initiaLbitmap);
                break;
            }
        }
    }


    private void scanWifi() {
        registerReceiver(wifiReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        wifiManager.startScan();
        Log.d("results","xlll");
//        Toast.makeText(MainActivity.this, "Scanning WiFi ...", Toast.LENGTH_SHORT).show();
    }

    BroadcastReceiver wifiReceiver = new BroadcastReceiver() {
        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public void onReceive(Context context, Intent intent) {
            results = wifiManager.getScanResults();
            unregisterReceiver(this);

            Log.d("results","x"+results.size());
            int bluetoothCount = arrayList.size();
            for (ScanResult scanResult : results) {
                arrayList.add(scanResult.capabilities + ","+scanResult.describeContents() + ","+scanResult.BSSID + ","+scanResult.SSID + "," + scanResult.level);
//                adapter.notifyDataSetChanged();
//                System.out.println("lassagn wifi: "+scanResult.capabilities + ","+scanResult.describeContents() + ","+scanResult.BSSID + ","+scanResult.SSID + "," + scanResult.level);

            }
//            System.out.println("#after: "+arrayList);
//            String collect = arrayList.stream().collect(Collectors.joining(","));
//            str = collect;
//            Submit("Innov 4.0"+","+floor+","+path+","+currentX+","+currentY+","+(bluetoothCount)+","+(arrayList.size()-bluetoothCount)+","+net, collect);
//            Log.d("Result",collect);
        }

    };

    private void Submit(String SSID1,String level1 )
    {
        SSID = SSID1;
        level = level1;

        String URL="http://172.23.92.113:3000/users";

//        final String finalSSID = SSID;
//        final String finalLevel = level;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(MainActivity.this,response,Toast.LENGTH_LONG).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this,error.toString(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<String, String>();

                params.put("name", SSID);
                params.put("value", level);
                System.out.println("*********"+params+"*********");
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        requestQueue.add(stringRequest);
    }

    public float[] ema(Queue<float[]> input){
        Queue<float[]> temp = new LinkedList<>(input);
        float[] avg = new float[3];
        int i=0;
        while (temp.size()>1){
            avg[0] = (float) (avg[0] + temp.peek()[0] * 0.1);
            avg[1] = (float) (avg[1] + temp.peek()[1] * 0.1);
            avg[2] = (float) (avg[2] + temp.peek()[2] * 0.1);
            temp.remove();
            i++;
        }
        if(temp.size()==1){
            avg[0] = (float) (avg[0] + temp.peek()[0]*0.9);
            avg[1] = (float) (avg[1] + temp.peek()[1]*0.9);
            avg[2] = (float) (avg[2] + temp.peek()[2]*0.9);
        }
        if (input.size()==0){
            System.out.println("zero");
            float[] zeros = new float[3];
            return zeros;
        }
        return (avg);
    }

    public void MyTimer() {
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @TargetApi(Build.VERSION_CODES.N)
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
            @Override
            public void run() {
                if (startWalk) {
                    Client client;
                    try {
                        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                        StrictMode.setThreadPolicy(policy);

                        if (netQueue.size() == 2){
                            netQueue.remove();
                            netQueue.add(axis);
                        }
                        else {
                            netQueue.add(axis);
                        }
//                        currentStr = "Innov 4.0"+","+floor+","+path+","+storeX+","+storeY+","+ema(netQueue)+","+arrayList.stream().collect(Collectors.joining("$"));
//                        client = new Client("172.23.93.5", 3000,currentStr + "^"+ previousStr); // need to change ip
//                        previousStr = currentStr;
//                        currentStr = "Innov 4.0"+","+floor+","+path+","+storeX+","+storeY+","+ema(netQueue)+","+arrayList.stream().collect(Collectors.joining("$"));
                        float[] tempOut = ema(netQueue);
                        currentStr = "Innov 4.0"+","+floor+","+path+","+storeX+","+storeY+","+tempOut[0]+","+tempOut[1]+","+tempOut[2];
                        client = new Client("172.23.8.205", 3000,currentStr); // need to change ip
//                        client = new Client("172.23.93.5", 3001,currentStr); // need to change ip
                        previousStr = currentStr;
                        arrayList.clear();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                } else {
                    // stop the timer
                    cancel();
                }
            }
        };
        timer.schedule(task, 0, period);
    }

}


class Client
{
    // initialize socket and input output streams
    private Socket socket = null;
    OutputStreamWriter osw;

    // constructor to put ip address and port

    public Client(String address, int port, String inStr) throws IOException, ClassNotFoundException {
        // establish a connection
        try
        {
            socket = new Socket(address, port);
            System.out.println("Connected to "+address + " port: "+port+" msg: "+inStr);
//            System.out.println(inStr);
            osw =new OutputStreamWriter(socket.getOutputStream(), "UTF-8");

        }
        catch(SocketException u)
        {
            System.out.println(u);
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
        try
        {
            osw.write(inStr, 0, inStr.length());
            osw.flush();
        }
        catch(IOException i)
        {
            System.out.println(i);
        }


        // close the connection
        try
        {
            osw.close();
            socket.close();
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
    }

}

